const mongoose=require('mongoose');
const URL="mongodb+srv://Admin:Admin1234@cluster0.vzitd9h.mongodb.net/Ecom?retryWrites=true&w=majority";
mongoose.connect(URL);
